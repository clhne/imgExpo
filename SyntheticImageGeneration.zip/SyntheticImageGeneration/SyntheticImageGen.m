function [ ] = SyntheticImageGen( im, savePath, newImName )
%  Synthetic Image Generation model

illuParm = [-72,-50,-35,0,35,60,80];
satuParm = [0,0,0,0,0,-20,-60];


im_hsv = rgb2hsv(im);
satu = im_hsv(:,:,2);
illu = im_hsv(:,:,3);

for classIndex = 1:7
    satuTemp = satu + 0.01 * satuParm(classIndex);
    illuTemp = illu + 0.01 * illuParm(classIndex);
    satuTemp(satuTemp>1)=1; satuTemp(satuTemp<0)=0;
    illuTemp(illuTemp>1)=1; illuTemp(illuTemp<0)=0;
    im_hsv(:,:,2) = satuTemp;
    im_hsv(:,:,3) = illuTemp;
    im = hsv2rgb(im_hsv);
    
    newPath = strcat(savePath ,num2str(classIndex));
    if(~exist(newPath, 'dir'))
        mkdir(newPath);
    end
    imwrite(im,strcat(newPath,'\',newImName));
end

end

