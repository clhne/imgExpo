This is the code for synthetic image generation.
Run run.m according to your demand.