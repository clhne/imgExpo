clear;
clc;
close all;

im = imread('reference\(5).bmp');
SyntheticImageGen( im, 'synthetic\', '(5).bmp');